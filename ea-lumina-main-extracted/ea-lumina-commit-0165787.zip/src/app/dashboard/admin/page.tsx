export const dynamic = 'force-dynamic'

import { StatCard } from '@/components/dashboard/StatCard'
import { PendingApprovalsAlert } from '@/components/admin/PendingApprovalsAlert'
import { prisma } from '@/lib/prisma'
import { formatCurrency } from '@/lib/utils'
import { Users, UserCheck, Calendar, DollarSign, AlertCircle } from 'lucide-react'
import { Badge } from '@/components/ui/Badge'
import Link from 'next/link'
import { headers } from 'next/headers'

async function getMetrics() {
  const [
    totalTherapists,
    totalPatients,
    totalAppointments,
    pendingApprovals,
    revenueResult,
    recentAppointments,
  ] = await Promise.all([
    prisma.user.count({ where: { role: 'TERAPEUTA' } }),
    prisma.user.count({ where: { role: 'PACIENTE' } }),
    prisma.appointment.count(),
    prisma.therapistProfile.count({ 
      where: { 
        approved: false,
        rejected: false,
        user: { role: 'TERAPEUTA' }
      } 
    }),
    prisma.appointment.aggregate({
      _sum: { platformRevenue: true },
      where: { status: { in: ['CONFIRMADO', 'CONCLUIDO'] } },
    }),
    prisma.appointment.findMany({
      take: 5,
      orderBy: { createdAt: 'desc' },
      include: {
        therapist: { include: { user: { select: { name: true } } } },
        patient: { include: { user: { select: { name: true } } } },
      },
    }),
  ])

  const totalRevenueGross = Number(revenueResult._sum.platformRevenue || 0)
  const totalGross = await prisma.appointment.aggregate({
    _sum: { price: true },
    where: { status: { in: ['CONFIRMADO', 'CONCLUIDO'] } }
  })
  
  const stripeFee = (Number(totalGross._sum.price || 0) * 0.0399) + (totalAppointments * 0.39)
  const totalRevenueNet = Math.max(0, totalRevenueGross - stripeFee)

  return {
    totalTherapists,
    totalPatients,
    totalAppointments,
    pendingApprovals,
    totalRevenue: totalRevenueNet,
    recentAppointments,
  }
}

const statusVariant: Record<string, 'success' | 'warning' | 'danger' | 'info' | 'default'> = {
  PENDENTE: 'warning',
  CONFIRMADO: 'success',
  CONCLUIDO: 'info',
  CANCELADO: 'danger',
}

const statusLabel: Record<string, string> = {
  PENDENTE: 'Pendente',
  CONFIRMADO: 'Confirmado',
  CONCLUIDO: 'Concluído',
  CANCELADO: 'Cancelado',
}

export default async function AdminDashboardPage() {
  const metrics = await getMetrics()

  return (
    <div className="p-6 space-y-6">
      {/* Alerta de aprovações pendentes */}
      <PendingApprovalsAlert initialCount={metrics.pendingApprovals} />

      {/* KPIs */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard
          title="Total de terapeutas"
          value={metrics.totalTherapists}
          icon={<UserCheck size={20} />}
          color="teal"
          description="Profissionais cadastrados"
        />
        <StatCard
          title="Total de pacientes"
          value={metrics.totalPatients}
          icon={<Users size={20} />}
          color="blue"
          description="Pacientes ativos"
        />
        <StatCard
          title="Total de agendamentos"
          value={metrics.totalAppointments}
          icon={<Calendar size={20} />}
          color="purple"
          description="Todos os status"
        />
        <StatCard
          title="Receita Líquida Real"
          value={formatCurrency(metrics.totalRevenue)}
          icon={<DollarSign size={20} />}
          color="gold"
          description="Descontadas taxas de cartão"
        />
      </div>

      <div className="flex flex-wrap gap-3">
        <Link
          href="/dashboard/admin/therapies"
          className="text-sm font-medium text-slate-700 hover:text-slate-800 bg-slate-50 border border-slate-200 rounded-xl px-4 py-2.5"
        >
          Gerenciar tipos de terapia →
        </Link>
      </div>

      {/* Últimos agendamentos */}
      <div className="bg-white rounded-xl border border-slate-200 shadow-sm">
        <div className="flex items-center justify-between p-5 border-b border-slate-100">
          <h2 className="text-sm font-semibold text-slate-900">Últimos agendamentos</h2>
          <Link href="/dashboard/admin/reports" className="text-xs text-slate-600 hover:text-slate-700 font-semibold">
            Ver todos →
          </Link>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-slate-100 bg-slate-50">
                <th className="text-left px-5 py-3 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Terapeuta</th>
                <th className="text-left px-5 py-3 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Paciente</th>
                <th className="text-left px-5 py-3 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Data</th>
                <th className="text-left px-5 py-3 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Valor</th>
                <th className="text-left px-5 py-3 text-[10px] font-semibold text-slate-500 uppercase tracking-wider">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {metrics.recentAppointments.map((apt) => (
                <tr key={apt.id} className="hover:bg-slate-50 transition-colors">
                  <td className="px-5 py-3.5 font-semibold text-slate-900 text-xs">{apt.therapist.user.name}</td>
                  <td className="px-5 py-3.5 text-slate-600 text-xs">{apt.patient.user.name}</td>
                  <td className="px-5 py-3.5 text-slate-500 text-xs">
                    {new Date(apt.date).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit' })}
                  </td>
                  <td className="px-5 py-3.5 font-semibold text-slate-900 text-xs">{formatCurrency(Number(apt.price))}</td>
                  <td className="px-5 py-3.5">
                    <Badge variant={statusVariant[apt.status] || 'default'} size="sm">
                      {statusLabel[apt.status] || apt.status}
                    </Badge>
                  </td>
                </tr>
              ))}
              {metrics.recentAppointments.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-5 py-10 text-center text-slate-400 text-sm">
                    Nenhum agendamento ainda
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}
